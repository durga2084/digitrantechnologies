<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<title>Partnerships</title>
	<style>
	
	</style>
</head>
<?php include 'header.php'; ?><br>	
<body>
	<div style="background-color: #79797d; color: #fff; padding: 50px 300px 30px 50px;">
		<h1>Our Partners</h1>
		<p> Our Federal government customer partners are Department of the Treasury Internal Revenue Service (IRS), Department of Health and Human 	   Services (DHHS), Department of Defense (DOD), and Social Security Administration (SSA).<br><br>
			We are a Pega consulting partner. Our other technology partners are Bizagi Freemium agile business process automation a low-code development platform and Amazon Web Services (AWS) cloud platform.<br><br>
			Our Business Partners are Peraton, Booz Allen Hamilton, Northrop Grumman, Leidos, Zolon Tech and CGI.<br><br>
			You can rest assured that we are bringing you cutting edge Digital Transformation solutions.<br><br>
		</p>
	</div><br>
	<div style="color: #1224b0;">	
		<div style="text-align: center; ">
			<h2>Customer Partners</h2>
			<img src="images/partner1.jpg" style="height: 200px; width: 200px; margin: 20px;">
			<img src="images/partner2.jpg" style="height: 200px; width: 200px; margin: 20px;">
			<img src="images/partner3.jpg" style="height: 200px; width: 200px; margin: 20px;">
			<img src="images/partner4.jpg" style="height: 200px; width: 200px; margin: 20px;">
		</div>
</div><br>
<div style="color: #1224b0;">	
		<div style="text-align: center; ">
			<h2>Technology Partners</h2>
			<img src="images/partner5.jpg" style="height: 250px; width: 250px; margin: 20px;">
			<img src="images/partner6.jpg" style="height: 250px; width: 250px; margin: 20px;">
			<img src="images/partner7.jpg" style="height: 250px; width: 250px; margin: 20px;">
		</div>
</div>
<div style="color: #1224b0;">	
		<div style="text-align: center; ">
			<h3>Customer Partners</h3>
			<img src="images/partner8.jpg" style="height: 200px; width: 200px; margin: 20px;">
			<img src="images/partner9.jpg" style="height: 200px; width: 200px; margin: 20px;">
			<img src="images/partner10.jpg" style="height: 200px; width: 200px; margin: 20px;">
			<img src="images/partner11.jpg" style="height: 200px; width: 200px; margin: 20px;"><br>
			<img src="images/partner12.jpg" style="height: 200px; width: 200px; margin: 20px;">
			<img src="images/partner13.jpg" style="height: 200px; width: 200px; margin: 20px;">
		</div>
</div>
<br>
</body>
</html>
<?php include 'footer.php' ?>