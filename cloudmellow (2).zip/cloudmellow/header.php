<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style>
		* {
			font-family: Verdana;
		}
		.navbar {
			background-color: white;
			width: 100%;
			height: 20%;
			top: 2%;
			margin-right: 0;

		}
		.logo {
			
			padding-left: 55px;
			padding-right: 205px;

		}
		.tabs a {
			text-decoration: none;
			margin-right: 15px;
			color: #52535c;
			font-weight: bold;

		}
	</style>
	<title>headerfile</title>
</head>
<body>
	<div style="padding: 5px; background-color:#3f4ebf; color: #fff; height: 30px;">
    <div style="float: left;">
        <p>&#9742; +1 (703) 593-2388</p>
    </div>
    <div style="float: right; text-decoration: none;">
        <p>&#9993; <a href="mailto:digitran@digitrantech.com" style="text-decoration: none; color: #fff; font-weight: 530;">digitran@digitrantech.com</a></p>
    </div>
    <div style="clear: both;"></div>
</div>
	<nav class="navbar">
	<a href="index.php"><img src="images/logo.jpg" style="height: 100px; width: 250px; padding-left: 55px;"></a>
		<span class="tabs">
		<a href="index.php" >Home</a>&nbsp&nbsp
		<a href="about.php">About Us</a>
		<a href="services.php">Services</a>
		<a href="partners.php">Partners</a>
		<a href="contract.php">Contracts</a>
		<a href="careers.php">Careers</a>
		<a href="contactform.php">Contact Us</a>
		</span>
	</nav>
</body>
</html>