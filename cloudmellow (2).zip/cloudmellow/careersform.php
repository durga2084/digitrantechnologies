<?php 
$conn = mysqli_connect("localhost", "root", "", "cloudmellow");

if ($conn->connect_error) {
	die("Connection Error" .$conn->connect_error);
} else {
	//echo "Connection Success";
}

$username = $phonenumber = $email = $technology = $resume = $message = $successmessage = "";
if($_SERVER["REQUEST_METHOD"] === "POST") {
	$username = $_POST["name"];
	$phonenumber = $_POST["phone"];
	$email = $_POST["email"];
	$technology = $_POST["technology"];
	$resume = $_POST["resume"];
	$message = $_POST["message"];

	// var_dump($username);
	// var_dump($phonenumber);
	// var_dump($email);
	// var_dump($technology);
	// var_dump($resume);

$sql = "INSERT INTO `job_apply`(`id`, `name`, `phone`, `email`, `technology`, `resume`, `message`) VALUES (NULL, '$username', '$phonenumber', '$email', '$technology', '$resume', '$message')";

if (mysqli_query($conn,$sql)) {
	$successmessage = "Your Application Received";
} else {
	echo "Failed to Insert";
}

}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="style.css">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/additional-methods.js" integrity="sha512-zkpudfSdDLH8HmFbtCZR6IZToMrwqM+rNgW9Fii8uIF2HX6M9GWClkGri+DeKHd0aDUClWX53PWdgg4n+e+lOQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>	
	<style>
		.careerform {
			margin-left: 155px;
			margin-right: 95px;
			padding: 25px;
		}
		.error {
			color: darkred;
		}

	</style>
	<title>Apply Now</title>
</head>
<body>
	<?php include 'header.php';?>
	<br><br>
	<div class="careerformdiv">
		<p class="ptext"><b>At DigiTran, we are dedicated to <br> understanding our customer’s <br> challenges and providing them <br> with transformative solutions to <br> meet their business needs.</b></p>	
	</div>
	<h2 style="margin-left: 75px; margin-top: 55px; color: royalblue;">Apply Job</h2>
	<form class="careerform" action="" method="post">
		<label>Your Name (required)</label><br>
		<input type="text" name="name" id="name"><br><br>
		<span id="nameerror" class="errormessage"></span>
		<label>Your Phone Number (required)</label><br>
		<input type="text" name="phone" id="phone"><br><br>
		<span id="phoneerror" class="errormessage"></span>
		<label>Your Email (required)</label><br>
		<input type="text" name="email" id="email"><br><br>
		<span id="emailerror" class="errormessage"></span>
		<label>Technology (required)</label><br>
		<input type="text" name="technology" id="technology"><br><br>
		<span id="technologyerror" class="errormessage"></span>
		<label>Upload Resume (required)</label><br>
		<input type="file" name="resume" id="resume"><br><br>
		<span id="resumeerror" class="errormessage"></span>
		<label>Your Message</label><br>
		<textarea name="message"></textarea><br><br>
		<input type="submit" name="submit" value="SUBMIT" class="submit" id="submit">
	</form>
	<div id="response"><?php $successmessage; ?></div>
	
	<script>
		$(document).ready(function() {
		$(".careerform").validate({
			rules: {
				technology:{
					required: true,
				}, 
				resume: {
					required: true,
				},
				name: {
					required: true,
					pattern: /^[a-zA-Z\s]*$/,
				},
				email: {
					required: true,
					email: true,
				},
				phone: {
					required: true,
					maxlength: 10,
					digits: true,
				}
			},
			messages: {
				technology:{
					 required:"Mention Your technologies",
				},
				resume: { 
					required:"Upload Your Resume",
				},
				name: {
					required: "Please Enter your Name",
					pattern: "Please Enter a Valid Name", 
				},
				email: {
					required: "Please enter your email",
					email: "Please enter a valid Email",
				},
				phone: {
					required: "Please enter your Phone Number",
					maxlength: "10 digits only",
					digits: "Please Enter a Valid Phone Numer",
				}
			}

		});
			
			var formdata = new formdata(this);
			$.ajax({
				url:'careersform.php',
				type:'POST',
				data:formdata,
				processData: false,
				contentType: false,
				success: function(respone) {
					$('#respone').html(respone);
				}

			});
		});
	</script>
</body>
</html>
<?php include 'footer.php';?>