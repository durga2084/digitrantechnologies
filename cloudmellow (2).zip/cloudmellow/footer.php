<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
  body {
    margin: 2%;
  }
* {
  box-sizing: border-box;
}
.footerrow {
  background-color: #000099;
  width: 100%;
  color: white;

  
  bottom: 2%;
}
.footercolumn {
  float: left;
  width: 25%;
  padding: 10px;
  height: 230px;
}

/* Clear floats after the columns */
.footerrow:after {
  content: "";
  display: table;
  clear: both;
}
.mail {
   content: "\2709";
}
.phone {
   content: "\260E";
}
.fa {
  padding: 8px;
  
  width: 30px;
  height: 30px;
  text-align: center;
  text-decoration: none;
/*  margin: 5px 2px;*/
}

.fa-facebook {
  background: #3B5998;
  color: white;
}
.fa-linkedin {
  background: #007bb5;
  color: white;
}
.fa-google {
  background: #dd4b39;
  color: white;
}
.fa-instagram {
  background: #125688;
  color: white;


</style>
</head>
<body>


<div class="footerrow">
  <div class="footercolumn">
    <h2>Address</h2>
    <p>13921 Park Center Road, Suite 530,<br> Herndon, VA 20171</p>
    <span class="mail">&#9993; digitran@digitrantech.com</span><br><br>
    <span class="phone">&#9742; +1 (703) 593-2388</span>
  </div>
  <div class="footercolumn">
    <h2>Quick Links</h2>
    <p></p>
    <p><span>&#127963;</span>&nbsp;<a href="contactform.php" style="color: white;text-decoration:none;"> Contact Us</a></p>
  </div>
  <div class="footercolumn">
    <h2>Social Media</h2>
    <a href="#" class="fa fa-facebook"></a>
    <a href="#" class="fa fa-linkedin"></a>
    <a href="#" class="fa fa-google"></a>
    <a href="#" class="fa fa-instagram"></a>
  </div>
  <div class="footercolumn">
    <h2>Newsletter</h2>
    <form>
      <label>Your Email (required)</label>
      <input type="text" name="newsemail" style="width:200px; height: 25px;"><br><br>
      <input type="submit" name="submit" value="SUBMIT" style="color:white;background-color:black; border-radius: 5px; height: 25px; width: 85px;">
    </form>
  </div>
</div>

</body>
</html>
