<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<title>Contracts</title>
	<style>
		.bodiv {
			background-color: #c3c4c2;
			border-radius: 12px;
			height: 500px;
			padding: 3%;
		}
	</style>
</head>
<?php include 'header.php';?><br>
<body>
	<div class="bodiv">
	<br><br>
	<h1>Contracts</h1>
	<p>General Services Administration – Multiple Award Schedule (GSA MAS)<br><br>
		Business Size Classification: Minority, Disadvantaged, Subcontinent<br> Asian (Asian-Indian) Owned Small Business<br><br>
		Contract Number: 47QTCA23D003U<br><br>
	Period Covered by Contract: 1/27/2023 – 1/26/2028 </p>
</div><br>
</body>
</html>
<?php include 'footer.php';?>