<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<title>Home</title>
</head>
<?php include 'header.php';?><br>
<body>
	<div id="carouselExampleCaptions" class="carousel slide">
 
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/slider1.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h2><b>Digital Transformation for the Government and Commercial Enterprise </b></h2>
         </div>
    </div>
    <div class="carousel-item">
      <img src="images/slider2.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h2><b>Innovative Solutions</b></h2>
      </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div><br>
<div class="ourmission">
<div class="row" style="background-color: #fff; width: 100%; height: 650px; margin: 1%;">
  <div class="column1" style="background-color:#aaa; width: 40%; border-radius:15px; padding: 2%;">
    <h1>Our Mission</h1>
    <p>To deliver tailored, innovative, end-to-end digital transformation services by applying advancing information and communication technologies to business processes.</p>
  </div>
  <div class="column" style="color: #494c9c; background-color:#c9c9d1; width: 18%; height: 100%; text-align: center; font-family: Verdana; border-radius: 15px; padding: 2%; margin: 1%;">
    <h2>Client Satisfaction</h2><br>
    <img src="images/col1.jpg" ><br><br>
    <p>Dedicated to providing personal attention to all our customer partners through productive and cost effective technology solutions and superior staffing.</p>
  </div>
  <div class="column" style="color: #494c9c; background-color:#c9c9d1; width: 17%; height: 100%; text-align: center; font-family: Verdana; border-radius: 15px; padding: 2%; margin: 1%;">
    <h2>Solution Delivery</h2><br>
    <img src="images/col2.jpg" ><br><br>
    <p>Ensuring accelerated digital transformation by anticipating future business needs.</p>
  </div>
  <div class="column" style="color: #494c9c; background-color:#c9c9d1; width: 17%; height: 100%; text-align: center; font-family: Verdana; border-radius: 15px; padding: 2%; margin: 1%;">
    <h3>Secure Agile Support</h3><br>
     <img src="images/col2.jpg" ><br><br>
    <p>Assured technical and resource support to respond quickly to changing business goals using scaled agile DevSecOps automated system life cycle development tools.</p>
  </div>
</div>
</div><br><br>

<div class="ourskills">
<div class="row">
	<div class="column" style="width:40%; background-color: #e2e8d3; height: 400px; padding: 150px 20px 100px 20px; color: black; border-radius: 10px;">
		<p>Our skills encompass providing digital transformation solutions through skilled human capital to design, develop, and manage the delivery of your solutions. We draw from our vast experience in Finance, Health, Defense, eCommerce, and Energy domains. Do reach out to us.</p>
	</div>
	<div class="column" style="width: 50%; background-color: #fff; margin: 3%;">
	<div>
		<button class="togglebutton1" style="height:40px; width:97%; border-radius: 13px; background-color: #8ce696;">Serving the Government and Commercial Enterprise</button><br><br>
		<p class="togglepara1">Be it the unique procurement procedures or the constraints of a legacy system, we are experienced with the nuances of delivery quality for the Federal Government. We are also well adapted to meeting the unique challenges that come with a rapidly changing business in the Commercial world.</p>
	</div><br>
	<div>
		<button class="togglebutton2" style="height:40px; width:97%; border-radius: 13px; background-color: #8ce696;">Digital Transformation Solutions Provider</button><br><br>
		<p class="togglepara2">We collaborate with our customer partners to evaluate business needs and translate them into functional and technical requirements to produce working software, and operate and maintain infrastructure.</p>
	</div><br>
	<div>
		<button class="togglebutton3" style="height:40px; width:97%; border-radius: 13px; background-color: #8ce696;">Human Capital Provisioning and Augmentation</button><br><br>
		<p class="togglepara3">With our quality-focused approach and years of experience across diverse customer base, we are adept at finding sought after professionals who are a good fit for your enterprise needs.</p>
	</div>	
</div>
</div><br>



<h1>Our Services</h1>
<div class="ourservices">
  <div class="row" style="background-color: #fff; color: #1d2980; height: 430px;">
    <div class="column" style="padding: 2%; display: inline-block; width: 24%;">
      <h4>Cloud Adoption, Migration, and Governance</h4>
      <img src="images/services2.jpg" style="max-width: 100%; height: auto;">
      <p>While the capabilities and breadth of the cloud are enormous, DigiTran helps your enterprise navigate challenges that come with the cloud.</p>
    </div>
    <div class="column" style="padding: 2%; display: inline-block; width: 24%;">
      <h4>Intelligent Low Code / No Code Platforms</h4>
      <img src="images/services17.jpg" style="max-width: 100%; height: auto;">
      <p>DigiTran has seen the need for business users to be able to quickly design, build, customize, and deploy business applications with little or no coding and Generative AI-driven data analytics.</p>
    </div>
    <div class="column" style="padding: 2%; display: inline-block; width: 24%;">
      <h4>Data Specialists</h4>
      <img src="images/services11.jpg" style="max-width: 100%; height: auto;">
      <p>DigiTran’s objective is to help create business value by gaining insights from data, eliminating data availability and quality issues by providing subject matter experts to help your enterprise achieve data-driven decision support.</p>
    </div>
    <div class="column" style="padding: 2%; display: inline-block; width: 24%;">
      <h4>Mobile Application Design, Development</h4>
      <img src="images/services14.jpg" style="max-width: 100%; height: auto;">
      <p>DigiTran’s success in mobile application design and development is evidenced in our successful cross-platform mobile applications across various industries such as Health, E-Learning, and E-Commerce.</p>
    </div>
  </div>
</div><br>

<div class="ourservices2">
<div class="row" style="background-color: #fff; color:#1d2980; height: 600px;">
  <div class="column" style="padding: 2%; display:inline-block; width:24%">
    <h4>Web Application Design, Development</h4>
    <img src="images/services17.jpg" style="max-width:100%; height: auto;">
    <p>In a largely digital world, a business relies on web applications for reporting, eCommerce, portals, accounting, intelligence to reach out to exponential audiences. DigiTran development process ensures that web applications are scalable, secure, easily maintained, and respond rapidly to requests. </p>
  </div>
  <div class="column" style="padding: 2%; display:inline-block; width:24%">
    <h4>Quality Management</h4>
    <img src="images/services23.jpg"  style="max-width:100%; height: auto;"><br><br>
    <p>Our Quality Assurance (QA) processes help solution delivery teams deliver high quality products efficiently. We use manual and automated testing tools for verification and validation.</p>
  </div>
 <div class="column" style="padding: 2%; display:inline-block; width:24%">
    <h4>Program & Project Management</h4>
    <img src="images/services19.jpg" style="max-width:100%; height: auto;"><br><br>
    <p>DigiTrans’s objective in managing our customer partner programs and projects is to ensure we deliver outcomes to achieve impact.</p>
  </div>
  <div class="column" style="padding: 2%; display:inline-block; width:24%">
    <h4>Human Capital</h4>
    <img src="images/services25.jpg" style="max-width:100%; height: auto;"><br><br>
    <p>DigiTran’s expertise in managing technology teams and solution delivery. with the right technologies and implementation skills help us collaborate with your enterprise to define and quickly bridge skill gaps, for your enterprise to stay agile.</p>
  </div>
</div>
</div><br>

<div style="text-align: center; color: #1d2980;">
<h1><b>Federal Partners</b></h1>
<img src="images/index1.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/index2.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/index3.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/index4.jpg" style="height: 200px; width: 200px; margin:10px;">
</div>
<br>
<div style="text-align: center; color: #1d2980;">
<h1><b>Business Partners</b></h1>
<img src="images/index5.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/index6.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/index7.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/index8.jpg" style="height: 200px; width: 200px; margin:10px;"><br>
<img src="images/index9.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/index10.jpg" style="height: 200px; width: 200px; margin:10px;">
</div>
<br>
<div style="text-align: center; color: #1d2980;">
<h1><b>Technology Partners</b></h1>
<img src="images/partner5.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/partner6.jpg" style="height: 200px; width: 200px; margin:10px;">
<img src="images/partner7.jpg" style="height: 200px; width: 200px; margin:10px;">
</div>
<br>
<div style="text-align: center; color: #1d2980;">
<h1><b>Technology Partners</b></h1>
<img src="images/index11.jpg" style="height: 120px; width: 200px; margin:20px;">
<img src="images/index12.jpg" style="height: 200px; width: 200px; margin:20px;">
</div>
<br>
<script>
	$(document).ready(function () {
		$(".togglepara1").hide();
		$(".togglebutton1").click(function(){
			$(".togglepara1").toggle();
			$(".togglepara2").hide();	
			$(".togglepara3").hide();
		});
		$(".togglepara2").hide();
		$(".togglebutton2").click(function(){
			$(".togglepara2").toggle();	
			$(".togglepara3").hide();
			$(".togglepara1").hide();
		});
		$(".togglepara3").hide();
		$(".togglebutton3").click(function(){
			$(".togglepara3").toggle();	
			$(".togglepara2").hide();
			$(".togglepara1").hide();
		});
	});
</script>
</body>
</html>
<?php include 'footer.php';?>