<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<title>About Us</title>
	<style>
		* {
			font-family: Tahoma;
		}
		#aboutdiv {
			color: white;
			background-color: #001a4d;
			padding: 5%;
			height: 350px;
		}
		.imgp {
			display: flex; 
			align-items: center; 
			margin-left: 150px; 
			margin-right:150px;
		}
		img {
			height: 300px; 
			width: 300px; 
			margin-right: 30px;
		}
		.heading {
			text-align: center;
		}
		.para {
			 margin-left: 150px; 
			 margin-right:150px; 
		}
		.core_values {
			color: #002b80;
			background-color: #f1f3f1;
			padding: 3%;
			padding-inline: 2%;
		}

	</style>
</head>
<?php include 'header.php'; ?><br>
<body>
	<div id="aboutdiv">
		<h1>About Us</h1>
		<p><b>DigiTran Technologies Inc.,</b> based in Northern Virginia, is a Small Disadvantaged Business (SDB), with depth and breadth of expertise in implementing Digital Transformation technologies in the Government and industry. We are dedicated to understanding our clients’ challenges to provide them with transformative information and communication technology solutions to meet their business needs. We make it easy and seamless for our clients to venture into new and ground-breaking technological areas. We provide innovative solutions through cost-effective and cutting-edge digital transformation technologies such as low-code/no-code platforms, big data, cloud, cognitive analytics, human centered design, and network and cyber security.</p>
	</div><br><br>
	<h1 class="heading"><b>Meet Our CEO</b></h1>

	<div class="imgp">
    <img src="images/ceo.jpg" alt="CEO" >
    <p style="margin-left: 10px;">
        <span style="color: #0000b3;"><b>Mr. Srinivas Mankala</b></span> has announced the successful launch of DigiTran, an IT Solutions company designed to deliver cutting-edge digital transformation technologies. With over 30 years of experience in both private and public sectors, Mr. Mankala has consistently focused on delivering innovative, cost-effective digital solutions to clients across the nation. Prior to launching DigiTran, Mankala served as CEO at NetVision Resources (NVR) in Northern Virginia. Under Mankala’s innovative leadership, the company transformed from a small business focused on IT services, staffing, and technology to a driving force in the IT sector by providing expertise in digital technologies including, but not limited to: Big Data, Cloud, Low code/No code environments, along with strategic, high-profile health IT solutions to federal agencies.
    </p>
</div>
<div class="para">
		<p>In his role of CEO, Mankala spearheaded the development of several major innovative solutions including the Blue Button Application for the Veterans Affairs (VA), Electronic Health Solutions for the National Institute of Standards Technology, cloud and scalable web architecture for Blackboard- an educational technology company, integrated intelligence proof-of-concept using open source technologies for Exxon, and ALPHA-D: a Health Predictive Analytics platform with a  focus on preventative healthcare for the Health IT field. Mr. Mankala has helped large Systems Integrators to achieve customer success through his staffing industry experience. He has staffed positions requiring niche skills and typically having long lead time with proven staffing processes. Mr. Mankala helped Northrup to meet its Social Security Administration (SSA) ITSSC contract goals by providing skilled personnel with SSA background and experience. For this effort, Mr. Manakala’s team received Supplier Excellence Award from Northrup</p>
	</div>
	<div class="para">
		<p>Mankala was the recipient of the “Influential Business Leader” award by Forbes and nominated for SmartCEO’s “Future 50”  In addition to earning numerous awards, Mankala’s work with the Jackson Laboratory in Bar Harbor, Maine was published in Nature.com. Mankala earned a Bachelor of Science in Civil Engineering from Osmania University (India) and a Master’s Degree in Computer Science from the New Jersey Institute of Technology (NJIT).</p>
	</div><br><br>
	<h1 class="heading">Our Executive Chairman</h1>
	<div class="imgp">
		<img src="images/executive.jpg" alt="Executive Chairman" style="border-radius: 50%;">
		<p style="margin-left: 10px;">As Executive Chairman, <span style="color:#0000b3;"><b>Shakil Kidwai</b></span> leads corporate strategy and direction at DigiTran. He is engaged at all levels of the organization, focused on expanding the company’s competencies, capabilities, and enhancing relationships with current and prospective customers. He believes deeply in servant leadership culture, offering guidance and mentorship at all levels. Shakil brings over 45 years of extensive executive management expertise, with a focus on growing organizations, delivering high value results to customers, and establishing a people-centered learning culture.</p>		
	</div>
	<div class="para"><p>Prior to joining DigiTran, Shakil Kidwai was the Vice President & General Manager of Peraton’s Citizen Services Business Unit (formally Northrop Grumman IT Services). He oversaw a portfolio of over $ 300M by building long-lasting partnerships with customers and business partners. He brings over four decades of Federal and Corporate Enterprise IT experience with a strong grasp on solving complex business problems with technology innovation.</p>	
	</div>
	<div class="para">
		<p>Prior to joining Northrop Grumman in 2008, Shakil had enjoyed a career at with Electronic Data Systems (EDS), where he had more than 32 years of progressive responsibility for International, Defense, State and Federal contracts, as the Senior Vice President of Global Information Assurance Group and ending his ending his career there as Senior Vice President DoD Service Delivery.</p>
	</div>
	<div class="para">
		<p>Shakil holds a bachelor’s degree in Mathematics and Statistics and has continued his education attending the Harvard Management and Leadership Course, John F. Kennedy School of Government, Harvard University and Global Leadership Course, at Thunderbird—The Garvin School of International Management.</p>
	</div><br>
	<h1 class="heading">Our Chief Growth Officer</h1>
	<div class="imgp">
		<img src="images/growthofficer.jpg" alt="Chief Growth Officer" style="border-radius: 50%">
		<p style="margin-left: 10px;"><span style="color:#0000b3;"><b>Chandrashekar (Chandra) Tamirisa</b></span> is DigiTran’s Chief Growth Officer with more than 20 years of business development experience in the private and government sectors in emerging technologies, contributing to digital transformation and critical infrastructure protection initiatives of the US government, leading to contracts of more than $2.25 billion in IDIQs and task orders from agencies, both civilian and defense, across the U.S. federal government.</p>
	</div>
	<div class="para">
		<p>He has worked for the Federal Reserve; as a program manager on digital transformation at Department of Commerce (DOC), National Oceanic and Atmospheric Administration (NOAA); and at GinnieMae, Department of Housing and Urban Development (HUD) in a client management/emerging technologies advisory role.</p>
	</div>
	<div class="para">
		<p>Chandra has graduate degrees in engineering, political science and applied economics.</p>
	</div>
	<div class="para">
		<p>In his role as Chief Growth Officer, Chandra will lead Digitran’s Federal acquisition strategy and execution to work with both US government agencies and small, medium, and large businesses in the digital transformation space serving the US government to derive maximum value for tax payer dollars for the information technology services provided by DigiTran to the US government.</p>
	</div><br>
	<div class="core_values">
		<h1 style="padding-inline: 2%;"><u>Our Co</u>re Values</h1>
		<ul>
			<li><b>Accountability</b>  To strive relentlessly, constantly improve ourselves, our teams, our services and products to become the best</li><br>
			<li><b>Commitment to Customers</b>  When a company represents a variety of businesses, commitment to each client is essential to success. DigiTran Technologies is a technology-based asset management company that works with high profile clients. Commitment to clients is one of Digitran’s core values because it establishes trust and encourages employees to go above and beyond no matter what.</li><br>
			<li><b>Leadership</b>  To set standards in our business and transactions and be an exemplar for the industry and ourselves</li><br>
			<li><b>Quality</b>  We take pride in providing high value products and services that we stand behind, which ensures customer satisfaction, profitability and the future of our employees and our growth.</li><br>
			<li><b>Teamwork</b>  Companies that assign teams to tasks are successful because teamwork encourages communication and the flow of ideas. Employees at the rapidly-growing tech company, DigiTran, work in teams because working with others allows each employee to bring their best to work. In fact, studies have proven that innovation is heightened in team settings.</li><br>
		</ul>
	</div>

<br><br>
</body>
</html>
<?php include 'footer.php'; ?>