<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<title>Services</title>
	<style>
		
	</style>
</head>
<?php include 'header.php'; ?><br>
<body>
	<div class="ourservices" style="display: flex; background-color: #04075c; ">
  <div style="width: 30%; padding: 5%; color: #fff;">
    <h1>Our Services</h1>
    <p>DigiTran Technologies supports the government and industry transform digital enterprises by streamlining business processes with advancing information and communication technologies.</p>
  </div>
  <div style="width: 70%; padding: 8%;">
    <img src="images/services1.jpg" style="max-width: 100%; height: auto;">
  </div>
</div>
<div style="display:flex; ">
	<div style="width:50%; margin: 15px; padding:8%;">
		<h3>Cloud Adoption, Migration and Governance</h3>
		<img src="images/services2.jpg">
		<p>Be it Microsoft Azure or Amazon AWS, DigiTran has the experience and expertise to ensure successful, secure, compliant utilization of the cloud for various applications. Our framework for cost optimization, resiliency, security and compliance lends guidance for an organization’s cloud governance. These best practices and automated integrity checks ensure that there are no roadblocks to product development.</p>
		<img src="images/services3.jpg">
		<img src="images/services4.jpg">
	</div>
	<div style="width: 40%; padding: 150px 50px 75px 10px;" >
		<img src="images/services5.jpg" style="height: 200px; width: 300px">
	</div>
</div>
<div style="display:flex;">
	<div style="width: 40%; padding: 5px 40px 75px 150px;" >
		<img src="images/services6.jpg" style="height: 200px; width: 300px">
	</div>
	<div style="color: #282763; margin-left:5%; width: 40%;">
		<h2>No Code/ Low Code platform/ tools</h2>
		<img src="images/services7.jpg">
		<p>Whether Low-Code or No-Code, DigiTran has the skills to help organizations select the right platform and train users to improve productivity by automating workflows with Pega, Appian, and ServiceNow.</p>
		<img src="images/services8.jpg">	
	</div>
</div>
<div style="display:flex;">
	<div style="width: 30%; padding: 5px 40px 75px 150px;">
		<h3>Data Specialists</h3>
		<img src="images/services11.jpg">	
	</div>
	<div style="width: 30%; padding: 5px;">
		<h4>Analytics and Visualization</h4>
		<p style="width: 95%">DigiTran’s experience has shown that interactive visualization provides better decision support than static data displays. We have expertise with both structure and unstructured data and scalability and experience in both open source and proprietary analytics tools such as R, Python, SAS, Apache Spark as well as Tableau, D3, HighCharts, and Leaflets, among others.</p>
		<img src="images/services12.jpg" style="width: 90%">
	</div>
	<div style="width: 30%; padding: 5px;">
		<h4>Data Management</h4>
		<p style="width: 95%">DigiTran has the experience and the skills to help an organization drive a data culture that stresses on quality data and shift towards a centralized data management strategy. Be it Data Warehousing (Informatica, Cloudera, Amazon Redshift…) with ETL and data cleansing, to data migrations (Oracle Data Service Integrator, Talend, …) or database design, modeling and performance tuning (for MS SQL, Oracle, Hadoop, PostgreSQL, MongoDB…), our data experts will find the right technology and process for an organization.</p>
		<img src="images/services13.jpg" style="width: 90%;">		
	</div>
</div>
<div style="display:flex; ">
	<div style="width:50%;	 padding:8%;">
		<h3>Mobile Application design, development</h3>
		<img src="images/services14.jpg">
		<p>Our skilled mobile architects and developers are well versed with solutions for interactive applications and content management with a clean architecture (MVVM (Model-View-View-Model), MVP (Model-View-Presenter), and so forth) and a strong optimization strategy for Web, Native and Hybrid deployments.</p>	
	</div>
	<div style="width: 40%; padding: 150px 50px 75px 10px;" >
		<img src="images/services15.jpg" style="height: 200px; width: 300px">
	</div>
</div>
<div style="display:flex;">
	<div style="width: 40%; padding: 5px 40px 75px 150px;" >
		<img src="images/services16.jpg" style="height: 200px; width: 300px">
	</div>
	<div style="color: #282763; margin-left:5%; width: 40%;">
		<h2>Web Application design, development</h2>
		<img src="images/services17.jpg">
		<p>In a digital world, a business relies largely on web applications for reporting, eCommerce, portals, accounting, intelligence, and of course, reaching out to a larger audience. DigiTran’s development process ensures that web applications are scalable, secure, easily maintained, and respond rapidly to requests. While we understand the reliability of proven technology stacks, we build for growth, looking to the future.</p>
		<img src="images/services18.jpg">	
	</div>
</div>
<div style="display:flex; ">
	<div style="width:50%; margin: 15px; padding:8%;">
		<h3>Program & Project management</h3>
		<img src="images/services19.jpg">
		<p>Adept at various methodologies (Agile, Traditional Waterfall), our project managers deliver real business value. As a crucial link between portfolios of strategic services in an organization and their component projects, our program managers strengthen the alignment towards organizational business strategy, ensure better control over the projects in the program and provide more focus towards benefits realization using advanced project and program management tools for planning and execution.</p>
		<img src="images/services20.jpg">
		</div>
	<div style="width: 40%; padding: 150px 50px 75px 10px;" >
		<img src="images/services21.jpg" style="height: 200px; width: 300px">
	</div>
</div>
<div style="display:flex;">
	<div style="width: 40%; padding: 5px 40px 75px 150px;" >
		<img src="images/services22.jpg" style="height: 200px; width: 300px">
	</div>
	<div style="color: #282763; margin-left:5%; width: 40%;">
		<h2>Quality Management</h2>
		<img src="images/services23.jpg">
		<p>Our quality Assurance, verification and validation experts are experienced with mobile and web application testing and in automated testing in the SAFe DevSecOps methodology and tools. We also have expertise in Selenium, UFT, TestComplete, Appium, Espresso, and Xamarin.</p>
		<img src="images/services24.jpg">	
	</div>
</div>
<div style="display:flex; ">
	<div style="width:50%; margin: 15px; padding:8%;">
		<h3>Human Capital Provisioning and Augmentation</h3>
		<img src="images/services25.jpg">
		<p>We take the time to vet our candidates and have built an in-house database of talent across the entire digital transformation lifecycle. We have strong relationships with our Federal and Commercial clients. We integrate new talent seamlessly for continuous support.</p>
		</div>
	<div style="width: 40%; padding: 150px 50px 75px 10px;" >
		<img src="images/services26.jpg" style="height: 200px; width: 300px">
	</div>
</div>


<br><br>
</body>
</html>
<?php include 'footer.php'; ?>