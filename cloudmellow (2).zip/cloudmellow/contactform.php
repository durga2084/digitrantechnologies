<?php 
$conn = mysqli_connect('localhost', 'root', '','cloudmellow');

if ($conn->connect_error) {
	die("Connection Failed" .$conn->connect_error);
} else {
	//echo "Connection Success";
}

$uername = $userphone = $useremail = $message = $successmessage = "";
if ($_SERVER["REQUEST_METHOD"] === "POST") {
	$username = $_POST['name'];
	$userphone = $_POST['phone'];
	$useremail = $_POST['email'];
	$message = $_POST['message'];

// var_dump($username);
// var_dump($userphone);
// var_dump($useremail);
// var_dump($message);
	$insert = "INSERT INTO `contact_form`(`id`, `name`, `phone`, `email`, `message`) VALUES (NULL,'$username','$userphone','$useremail','$message')";

	if (mysqli_query($conn, $insert)) {
		$successmessage = "Inserted Successfully";
	} else {
		echo "Failed";
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/additional-methods.js" integrity="sha512-zkpudfSdDLH8HmFbtCZR6IZToMrwqM+rNgW9Fii8uIF2HX6M9GWClkGri+DeKHd0aDUClWX53PWdgg4n+e+lOQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<title>Contact Us</title>
	<style>
		*{
			font-family: arial;
		}
		#contdiv {
			text-align: center;
			height: 400px;
			color: white;
			background-color: #9999ff;
			padding-top: 15%;
			padding-bottom: 25%;

		}
		#box {
			padding-top: 3%;
			margin-left: 25%;
			margin-right: 25%;
			background-color: skyblue;
			height: 700px;
			widows: 300px;
			border: 2px black;
			border-radius: 8px;
		}
		.contactform {
			padding-left: 8%;
			padding-right: 8%;
		}
		input[type=text] {
			height: 45px;
			width: 100%;
			border: 1px blue;
			border-radius: 10px;
			padding: 8px;
		}
		textarea {
			height: 135px;
			width: 100%;
			border: 1px blue;
			border-radius: 10px;
			padding: 8px;
		}
		input[type=submit] {
			height: 45px;
			width: 30%;
			border-radius: 10px;
			color: white;
			background-color: black;
		}
		.error {
			color: red;
		}
		.address {
			text-align: center;
		}
	</style>
</head>
<?php include 'header.php'; ?><br>
<body>
	<div id="contdiv">
		<h1>Contact Us</h1>
		<p>Digital Transformation for the Government and Commercial<br> Enterprise</p>
	</div>
	<div id="box">
		<div style="text-align: center;">
			<h2>Get in Touch</h2>
			<p>Please complete the details below and then <br>click on Submit and we’ll be in contact</p>
		</div><br><br>
	<form class="contactform" action="" method="post">
		<label>Your Name (required)</label><br>
		<input type="text" name="name" id="name"><br>
		<label>Your Phone Number (required)</label><br>
		<input type="text" name="phone" id="phone"><br>
		<label>Email Address (required)</label><br>
		<input type="text" name="email" id="email"><br>
		<label>Your Message</label><br>
		<textarea name="message"></textarea><br>
		<input type="submit" name="submit" id="submit" value="SEND">
	</form>
</div><br>
<div class="address">
		<p>CONTACT</p>
		<h1>Get in touch</h1>
		<img src="images/address.jpg" style="height: 170px; width: 170px;">
		<p><b>USA Office</b><br>13921 Park Center Road, Suite 530, Herndon, VA 20171</p>
	</div>
<script>

	$(document).ready(function() {
		$(".contactform").validate({
			rules: {
				name: {
					required: true,
					pattern: /^[a-zA-Z\s]*$/,
				},
				email: {
					required: true,
					email: true,
				},
				phone: {
					required: true,
					maxlength: 10,
					digits: true,
				}
			},
			messages: {
				name: {
					required: "Please Enter your Name",
					pattern: "Please Enter a Valid Name", 
				},
				email: {
					required: "Please enter your email",
					email: "Please enter a valid Email",
				},
				phone: {
					required: "Please enter your Phone Number",
					maxlength: "10 digits only",
					digits: "Please Enter a Valid Phone Numer",
				}
			}

		});


		var formdata = new formdata(this);
		$.ajax({
			url:'contactform.php',
			type:'POST',
			data:formdata,
			processData: false,
			contentType: false,
			success: function(response) {
				$('#response').html(response);
			}

		});

	});
</script>
<span id="successmessage"><?php echo $successmessage; ?></span>

</body>
</html>

<?php include 'footer.php' ?>