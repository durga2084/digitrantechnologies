<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
	<link rel="stylesheet" href="style.css">
	<style>
		* {
			font-family: Verdana;
		}
		.ptext {
			padding-left: 85px;
			padding-top: 85px;
			height: 455px;
			background-color: #cccccc;
			font-size: 25px;
		}
		.job {
			margin: 65px;
			background-color: #cccccc;
			padding: 18px;
			overflow
		}
		span {
			color: blue;
		}
		button {
			color: white;
			background-color: darkblue;
			height: 45px;
			width: 115px;
		}
		.headdiv {
			margin-top: 0px;
		}
	</style>
	<title>Careers</title>
</head>
<body>
<div class="headdiv">
	<?php include 'header.php'; ?>
</div>
	<p class="ptext"><b>At DigiTran, we are dedicated to <br> understanding our customer’s challenges <br> and providing them with transformative <br>solutions to meet their business needs.</b></p>
	<h3>Latest Openings</h3>
	<div class="job">
		<p><span>Title: Pega Lead System Architect<br>
			Location: Woodlawn, MD<br>
			Duration: Long term<br>
			Job Description:</span><br>
			<ul>
				<li>The Pega Lead System Architect (LSA) will support a Center of Excellence (COE) that, through the delivery and reporting of Platform key services, can help bridge the layers in the Platform governance model to ensure optimal opportunity to drive value as well as ensuring issues and risks are properly escalated. As a member of the cross-domain support team, the LSA will support stakeholders in planning and implementing the Pega Platform in Digital transformation and IT modernization, and digital process automation initiatives through:</li>
				<li>Clear strategic vision and approach to projects</li>
				<li>Establishing and fostering partnership and trust between the Business and Systems</li>
				<li>Developing Proof of Concepts and application mock-ups to quickly help demonstrate Pega capabilities</li>
				<li>Integrating process optimization and innovation engineering efforts into projects</li>
				<li>Defining and promoting best practices around technologies</li>
				<li>Creating and maintaining architectural standards</li>
				<li></li>
				<li>Promoting standard methodologies, tools and processes in support of project delivery across stakeholders</li>
				<li>Drive enablement of project and business resources</li>
				<li>Ensure proper governance</li>
				<li>Drive maturity within the organization</li>
				<li>The Pega LSA will act as a liaison between the business users, stakeholders and technical leads.</li>
				<li>This individual will be responsible to work with senior SSA leadership and Pega Technical Leads jointly charting business and technical strategies.</li>
				<li>Working on-site at a customer location, this role will interact with and communicate product requirements to architects, engineers, development managers, product managers, testers, and other stakeholders</li>
			</ul>
			<span>Basic Qualifications:</span><br>
			<ul>
				<li>Minimum knowledge, skills, abilities needed.</li>
				<li>Bachelor’s Degree and 7 years of work experience; Masters and 5 years of experience; or a minimum 11 years of work experience in lieu of a degree.</li>
				<li>Pega Certified Lead System Architect (PCLSA) certification</li>
				<li>7+ years of relevant design and architecture experience</li>
				<li>3+ years of experience in Pega version 7.x or greater</li>
				<li>3+ years of experience with Connectors and Services in Pega Rules Process Commander (PRPC) to integrate with external systems </li>
				<li>2+ years of experience with the following:</li>
				<li>Pega CRM or Customer Service</li>
				<li>Documenting Pega Standards and Guardrails</li>
				<li>Agile (Scrum)</li>
				<li>Ability to create system architecture diagrams and documentation for review by both technical and non-technical audiences, as well as interface with the customer on a daily basis.</li>
				<li>Must be able to obtain and maintain a Public Trust clearance</li>
			</ul>
			<span>Preferred Qualifications:</span><br>
			<ul>
				<li>Candidates with these skills will be given preferential consideration.</li>
				<li>Strong verbal and written communication skills.</li>
				<li>Experience with process flow documentation creation, presentation and conducting trainings.</li>	
				<li>Experience with implementing DevOps (Test and CI/CD) in a Pega environment</li>
				<li>Experience with Oracle and stored procedures using PL/SQL</li>
				<li>Experience with designing and implementing REST based API integration services</li>
			</ul>
		</p>
		<a href="careersform.php"><center><button>Apply Now</button></center></a>
	</div>

</body>
</html>
<?php include 'footer.php';?>